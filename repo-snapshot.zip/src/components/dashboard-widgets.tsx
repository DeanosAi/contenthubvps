"use client"

import type { Job } from '@/lib/types'
import { computeDashboardCounts } from '@/lib/calendar'

/** Identifier for each dashboard widget. The parent maps these to the
 * appropriate filter state when a widget is clicked. */
export type WidgetKey =
  | 'overdue'
  | 'dueThisWeek'
  | 'awaitingApproval'
  | 'recentlyPosted'
  | 'inFlight'

interface WidgetDef {
  key: WidgetKey
  label: string
  /** Tone for the count (red for warnings, etc). */
  accent: 'red' | 'amber' | 'cyan' | 'emerald' | 'slate'
  /** Optional one-line caption shown under the count. */
  caption?: string
}

/**
 * Round 7.2b changes:
 *   - "In flight" → "Active jobs" (the old name was opaque jargon).
 *     The widget key stays `inFlight` so existing filter-routing
 *     code in app-shell continues to work without churn.
 *   - "Recently posted" → "Recently posted/live" to match the new
 *     kanban column label ("Posted/Live").
 */
const WIDGETS: WidgetDef[] = [
  { key: 'overdue', label: 'Overdue', accent: 'red', caption: 'Past due, not yet posted' },
  { key: 'dueThisWeek', label: 'Due this week', accent: 'amber', caption: 'Next 7 days' },
  { key: 'awaitingApproval', label: 'Awaiting approval', accent: 'cyan', caption: 'Needs client sign-off' },
  { key: 'recentlyPosted', label: 'Recently posted/live', accent: 'emerald', caption: 'Last 7 days' },
  { key: 'inFlight', label: 'Active jobs', accent: 'slate', caption: 'Excluding archive' },
]

/**
 * Round 7.2b colour palette — light theme.
 *
 * Pre-7.2b these used `text-{color}-300` for the count and ring
 * intensities tuned for dark backgrounds, which rendered as washed-
 * out pastels on the slate-100 page. New scheme: saturated -700 text
 * for readability, -50 background tints for visible cards, -200/-300
 * borders that work on white.
 *
 * Round 7.2b.1: the "amber" accent (used by "Due this week") was
 * reading as orange-red on screen because Tailwind's amber-700 is a
 * deep brownish-orange (#b45309) — visually too close to red-700.
 * Swapped the visual classes to Tailwind's yellow palette
 * (yellow-600 = #ca8a04) so the tile reads clearly as yellow. The
 * accent key name stays 'amber' to avoid churn elsewhere.
 */
const ACCENT_RING: Record<WidgetDef['accent'], string> = {
  red: 'ring-red-200 hover:ring-red-400',
  amber: 'ring-yellow-200 hover:ring-yellow-400',
  cyan: 'ring-cyan-200 hover:ring-cyan-400',
  emerald: 'ring-emerald-200 hover:ring-emerald-400',
  slate: 'ring-slate-200 hover:ring-slate-400',
}

const ACCENT_TEXT: Record<WidgetDef['accent'], string> = {
  red: 'text-red-700',
  amber: 'text-yellow-600',
  cyan: 'text-cyan-700',
  emerald: 'text-emerald-700',
  slate: 'text-slate-700',
}

const ACCENT_DOT: Record<WidgetDef['accent'], string> = {
  red: 'bg-red-500',
  amber: 'bg-yellow-500',
  cyan: 'bg-cyan-500',
  emerald: 'bg-emerald-500',
  slate: 'bg-slate-500',
}

/**
 * Strip of clickable summary cards rendered above the kanban. Each card
 * shows a count of jobs in some interesting bucket; clicking applies the
 * matching filter to the kanban below.
 *
 * The widgets compute their counts from the FULL job list (not the
 * already-filtered one) — otherwise applying a filter would zero-out
 * the other widgets, which is confusing. The "Active jobs" total
 * includes everything not archived and is the headline metric on the right.
 */
export function DashboardWidgets({
  jobs,
  activeWidget,
  onSelectWidget,
}: {
  /** Full job list for the current workspace selection (NOT filtered). */
  jobs: Job[]
  /** Which widget is currently driving the kanban filter, if any.
   * Used to highlight the active card. Pass null when filters are at default. */
  activeWidget: WidgetKey | null
  /** Click handler. Pass `null` when the same widget is clicked again to
   * reset. The parent translates the key into a JobFilterState patch. */
  onSelectWidget: (next: WidgetKey | null) => void
}) {
  const counts = computeDashboardCounts(jobs)
  const valueByKey: Record<WidgetKey, number> = {
    overdue: counts.overdue,
    dueThisWeek: counts.dueThisWeek,
    awaitingApproval: counts.awaitingApproval,
    recentlyPosted: counts.recentlyPosted,
    inFlight: counts.inFlight,
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
      {WIDGETS.map((w) => {
        const isActive = activeWidget === w.key
        const value = valueByKey[w.key]
        return (
          <button
            key={w.key}
            type="button"
            onClick={() => onSelectWidget(isActive ? null : w.key)}
            className={`text-left rounded-2xl border border-slate-200 bg-white surface-shadow p-4 ring-1 ring-transparent transition-all ${
              isActive
                ? `${ACCENT_RING[w.accent]} ring-2`
                : `${ACCENT_RING[w.accent]} hover:ring-1`
            }`}
            aria-pressed={isActive}
          >
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${ACCENT_DOT[w.accent]}`} />
              <span className="text-xs uppercase tracking-wider text-slate-600 font-semibold">
                {w.label}
              </span>
            </div>
            <p className={`mt-2 text-3xl font-bold ${ACCENT_TEXT[w.accent]}`}>{value}</p>
            {w.caption && (
              <p className="mt-1 text-[11px] text-slate-500">{w.caption}</p>
            )}
            {isActive && (
              <p className="mt-2 text-[10px] uppercase tracking-wider text-indigo-700 font-semibold">
                Filtering kanban — click again to clear
              </p>
            )}
          </button>
        )
      })}
    </div>
  )
}
